with open("hoge.txt", "wt") as f:
    f.write("いろはにほへと")

