with open("hoge.txt", "wt", encoding="utf-8") as f:
    f.write("いろはにほへと")

