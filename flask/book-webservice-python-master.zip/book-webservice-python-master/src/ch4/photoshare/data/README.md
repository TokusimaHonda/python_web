このフォルダに photos.sqlite3 が保存されます

